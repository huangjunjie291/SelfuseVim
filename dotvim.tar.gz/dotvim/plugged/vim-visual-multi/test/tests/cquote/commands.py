# change inside/around double quotes
keys(r'fh')
keys(r'\<C-Down>\<C-Down>')
keys(r'ci\"')
keys(r'test')
keys(r'\<Esc>\<Esc>')
keys(r'uugg0')
keys(r'fh')
keys(r'\<C-Down>\<C-Down>')
keys(r'ca\"')
keys(r'test')
keys(r'\<Esc>\<Esc>')

