# visual select, cc
L = '\\\\\\\\'
keys('ve')
keys(L + 'A')
keys('\<Tab>')
keys('cc')
keys('test')
keys('\<Esc>\<Esc>')
