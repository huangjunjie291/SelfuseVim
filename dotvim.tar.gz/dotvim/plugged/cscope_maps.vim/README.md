A mirror of [cscope\_maps.vim](http://cscope.sourceforge.net/cscope_maps.vim),
with my adjustments.
