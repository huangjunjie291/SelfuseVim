---
name: "Feature Request"
about: "What new feature are you requesting for NERDTree?"
labels: "feature request"
---

#### Description

